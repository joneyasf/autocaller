package com.example.autocaller.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.autocaller.data.AppDatabase
import com.example.autocaller.data.RepeatType
import com.example.autocaller.data.ScheduledCall
import com.example.autocaller.ui.MainActivity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object AlarmScheduler {
    const val EXTRA_CALL_ID = "call_id"
    private const val TAG = "AlarmScheduler"

    /** Next trigger time in epoch millis, or null if there is none (expired one-time call). */
    fun nextTriggerMillis(call: ScheduledCall, now: LocalDateTime = LocalDateTime.now()): Long? {
        val time = LocalTime.of(call.hour, call.minute)
        val startDate = LocalDate.ofEpochDay(call.dateEpochDay)
        val start = LocalDateTime.of(startDate, time)

        val next: LocalDateTime? = when {
            start.isAfter(now) -> start
            call.repeat == RepeatType.ONCE -> null
            call.repeat == RepeatType.DAILY -> {
                val today = LocalDateTime.of(now.toLocalDate(), time)
                if (today.isAfter(now)) today else today.plusDays(1)
            }
            else -> { // WEEKLY: same weekday as the start date
                val days = ChronoUnit.DAYS.between(startDate, now.toLocalDate())
                var candidate = LocalDateTime.of(startDate.plusDays(days / 7 * 7), time)
                while (!candidate.isAfter(now)) candidate = candidate.plusWeeks(1)
                candidate
            }
        }
        return next?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
    }

    /** Schedules (or cancels, if disabled/expired) the alarm of one call. */
    fun schedule(context: Context, call: ScheduledCall): Boolean {
        cancel(context, call.id)
        if (!call.enabled) return false
        val triggerAt = nextTriggerMillis(call) ?: return false

        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val showIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return try {
            // setAlarmClock => fires exactly, wakes the device and bypasses Doze.
            alarmManager.setAlarmClock(
                AlarmManager.AlarmClockInfo(triggerAt, showIntent),
                operationIntent(context, call.id)
            )
            true
        } catch (e: SecurityException) {
            Log.w(TAG, "Cannot schedule exact alarm", e)
            false
        }
    }

    fun cancel(context: Context, callId: Long) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val pi = operationIntent(context, callId)
        alarmManager.cancel(pi)
        pi.cancel()
    }

    suspend fun rescheduleAll(context: Context) {
        AppDatabase.get(context).callDao().getEnabled().forEach { schedule(context, it) }
    }

    private fun operationIntent(context: Context, callId: Long): PendingIntent {
        val intent = Intent(context, CallAlarmReceiver::class.java)
            .putExtra(EXTRA_CALL_ID, callId)
        return PendingIntent.getBroadcast(
            context,
            callId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
