package com.example.autocaller.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.autocaller.data.AppDatabase
import com.example.autocaller.data.RepeatType
import com.example.autocaller.service.CallPlacer
import com.example.autocaller.service.CallService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val callId = intent.getLongExtra(AlarmScheduler.EXTRA_CALL_ID, -1L)
        if (callId < 0) return
        val appContext = context.applicationContext

        var serviceStarted = true
        try {
            ContextCompat.startForegroundService(
                appContext,
                Intent(appContext, CallService::class.java)
                    .putExtra(AlarmScheduler.EXTRA_CALL_ID, callId)
            )
        } catch (e: Exception) {
            Log.e("CallAlarmReceiver", "Could not start CallService", e)
            serviceStarted = false
        }

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(appContext).callDao()
                val call = dao.getById(callId) ?: return@launch
                // Re-arm the next occurrence right away for repeating calls.
                if (call.enabled && call.repeat != RepeatType.ONCE) {
                    AlarmScheduler.schedule(appContext, call)
                }
                // Fallback: service could not start, place the call from here.
                if (!serviceStarted && call.enabled) {
                    CallPlacer.place(appContext, call.number)
                    if (call.repeat == RepeatType.ONCE) dao.update(call.copy(enabled = false))
                }
            } finally {
                pending.finish()
            }
        }
    }
}
