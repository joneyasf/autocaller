package com.example.autocaller.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.example.autocaller.R
import com.example.autocaller.data.AppDatabase
import com.example.autocaller.data.RepeatType
import com.example.autocaller.data.ScheduledCall
import com.example.autocaller.scheduler.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class CallService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(getString(R.string.notif_running)),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
            )
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed", e)
        }

        val callId = intent?.getLongExtra(AlarmScheduler.EXTRA_CALL_ID, -1L) ?: -1L
        if (callId < 0) { // sticky restart without data
            stopSelf(startId)
            return START_NOT_STICKY
        }

        scope.launch {
            try {
                val dao = AppDatabase.get(applicationContext).callDao()
                val call = dao.getById(callId)
                if (call != null && call.enabled) {
                    notify(buildNotification(getString(R.string.notif_calling, call.name)))
                    val ok = CallPlacer.place(applicationContext, call.number)
                    if (!ok) showFailure(call)
                    if (call.repeat == RepeatType.ONCE) dao.update(call.copy(enabled = false))
                    delay(5_000) // keep the process alive while the dialer comes up
                }
            } catch (e: Exception) {
                Log.e(TAG, "Call execution failed", e)
            } finally {
                stopSelf(startId)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .build()

    private fun notify(notification: Notification) {
        try {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            Log.w(TAG, "No notification permission", e)
        }
    }

    private fun showFailure(call: ScheduledCall) {
        val dial = PendingIntent.getActivity(
            this, call.id.toInt(),
            Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", call.number, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(getString(R.string.notif_failed, call.name))
            .setContentText(getString(R.string.notif_failed_hint))
            .setContentIntent(dial)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(this).notify(FAILURE_ID_BASE + call.id.toInt(), n)
        } catch (e: SecurityException) {
            Log.w(TAG, "No notification permission", e)
        }
    }

    companion object {
        private const val TAG = "CallService"
        private const val CHANNEL_ID = "calls_channel"
        private const val NOTIFICATION_ID = 1001
        private const val FAILURE_ID_BASE = 2000
    }
}
