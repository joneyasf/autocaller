package com.example.autocaller.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.autocaller.R
import com.example.autocaller.data.RepeatType
import com.example.autocaller.data.ScheduledCall
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val ArabicLocale: Locale = Locale.forLanguageTag("ar")
internal val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", ArabicLocale)
internal val timeFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("hh:mm a", ArabicLocale)

/** Converts Arabic-Indic digits to ASCII and drops everything except digits, +, * and #. */
private fun normalizeNumber(raw: String): String = buildString {
    for (c in raw) {
        when {
            c.isDigit() -> {
                val d = Character.digit(c, 10)
                if (d >= 0) append('0' + d)
            }
            c == '+' || c == '*' || c == '#' -> append(c)
        }
    }
}

@Composable
fun repeatLabel(repeat: RepeatType): String = stringResource(
    when (repeat) {
        RepeatType.ONCE -> R.string.once
        RepeatType.DAILY -> R.string.daily
        RepeatType.WEEKLY -> R.string.weekly
    }
)

@Composable
fun CallEditDialog(
    initial: ScheduledCall?,
    onDismiss: () -> Unit,
    onSave: (ScheduledCall) -> Unit
) {
    val context = LocalContext.current
    val defaultDt = remember { LocalDateTime.now().plusMinutes(2) }

    var name by remember { mutableStateOf(initial?.name ?: "") }
    var number by remember { mutableStateOf(initial?.number ?: "") }
    var date by remember {
        mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.dateEpochDay) } ?: defaultDt.toLocalDate())
    }
    var time by remember {
        mutableStateOf(
            initial?.let { LocalTime.of(it.hour, it.minute) }
                ?: LocalTime.of(defaultDt.hour, defaultDt.minute)
        )
    }
    var repeat by remember { mutableStateOf(initial?.repeat ?: RepeatType.ONCE) }
    var errorRes by remember { mutableStateOf<Int?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (initial == null) R.string.add_call else R.string.edit_call))
        },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.name)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it; errorRes = null },
                    label = { Text(stringResource(R.string.number)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr),
                    isError = errorRes == R.string.err_number,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, y, m, d -> date = LocalDate.of(y, m + 1, d); errorRes = null },
                            date.year, date.monthValue - 1, date.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("${stringResource(R.string.date)}: ${date.format(dateFormatter)}") }

                OutlinedButton(
                    onClick = {
                        TimePickerDialog(
                            context,
                            { _, h, min -> time = LocalTime.of(h, min); errorRes = null },
                            time.hour, time.minute, false
                        ).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("${stringResource(R.string.time)}: ${time.format(timeFormatter)}") }

                Text(stringResource(R.string.repeat), style = MaterialTheme.typography.labelLarge)
                RepeatType.values().forEach { option ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = repeat == option,
                                onClick = { repeat = option; errorRes = null },
                                role = Role.RadioButton
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = repeat == option, onClick = null)
                        Text(repeatLabel(option), Modifier.padding(start = 8.dp))
                    }
                }

                errorRes?.let {
                    Text(
                        stringResource(it),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val clean = normalizeNumber(number)
                if (clean.isEmpty()) {
                    errorRes = R.string.err_number
                } else if (repeat == RepeatType.ONCE &&
                    !LocalDateTime.of(date, time).isAfter(LocalDateTime.now())
                ) {
                    errorRes = R.string.err_past
                } else {
                    onSave(
                        ScheduledCall(
                            id = initial?.id ?: 0L,
                            name = name.trim().ifEmpty { clean },
                            number = clean,
                            dateEpochDay = date.toEpochDay(),
                            hour = time.hour,
                            minute = time.minute,
                            repeat = repeat,
                            enabled = true
                        )
                    )
                }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}
