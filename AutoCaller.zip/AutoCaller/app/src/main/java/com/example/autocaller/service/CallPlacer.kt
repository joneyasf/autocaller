package com.example.autocaller.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat

object CallPlacer {
    private const val TAG = "CallPlacer"

    /**
     * false = ACTION_CALL first, TelecomManager.placeCall as fallback (as requested).
     * Android 10+ may silently block activity launches from the background.
     * If calls don't start with the screen off, set this to true.
     */
    private const val TELECOM_FIRST = false

    fun place(context: Context, number: String): Boolean {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) return false

        val uri = Uri.fromParts("tel", number, null)
        var ok = if (TELECOM_FIRST) viaTelecom(context, uri) else viaIntent(context, uri)
        if (!ok) ok = if (TELECOM_FIRST) viaIntent(context, uri) else viaTelecom(context, uri)
        return ok
    }

    @SuppressLint("MissingPermission")
    private fun viaIntent(context: Context, uri: Uri): Boolean = try {
        context.startActivity(
            Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (e: Exception) {
        Log.w(TAG, "ACTION_CALL failed", e)
        false
    }

    @SuppressLint("MissingPermission")
    private fun viaTelecom(context: Context, uri: Uri): Boolean = try {
        context.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
        true
    } catch (e: Exception) {
        Log.w(TAG, "TelecomManager.placeCall failed", e)
        false
    }
}
