package com.example.autocaller.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

enum class RepeatType { ONCE, DAILY, WEEKLY }

@Entity(tableName = "scheduled_calls")
data class ScheduledCall(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val number: String,
    /** Start date as LocalDate.toEpochDay() */
    val dateEpochDay: Long,
    val hour: Int,
    val minute: Int,
    val repeat: RepeatType = RepeatType.ONCE,
    val enabled: Boolean = true
)

class Converters {
    @TypeConverter
    fun fromRepeat(value: RepeatType): String = value.name

    @TypeConverter
    fun toRepeat(value: String): RepeatType = RepeatType.valueOf(value)
}
